/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progchatapp;
import java.util.Scanner;

/**
 *
 * @author vukosi.shivuri
 */

public class ProgChatApp{

    public void main(String[] args) {
        /*Below code is for a scanner to read the user input */
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the WhatsApp ChatBox.");

        /* This is for registration object to access validation methods */
        Registration registration = new Registration();
        System.out.println("---> Registration <---");

        //Below is for asking user to enter their login details
        System.out.println("Please, Enter your First Name: ");
        String firstName = input.nextLine();

        System.out.println("Please, Enter your Last Name: ");
        String lastName = input.nextLine();

        /* This is for user to enter login details */

        String username;
        do{
            System.out.println("Enter your username: " + "(must contain an underscore, and be less than 5 characters)");
            username = input.nextLine();
            System.out.println(registration.returnUserNameMessage(username));
        }while (!registration.checkUserName(username));

        String password;
        do{
            System.out.println("Enter your password: " + "(password must be: "
                    + "at least 8 characters long, "
                    + "contain a capital letter, "
                    + "contain a number,"
                    + "contain a special character.)");
            password = input.nextLine();
            System.out.println(registration.returnCheckPasswordMessage(password));
        }while (!registration.checkPasswordComplexity(password));

        String cellPhoneNumber;
        do{
            System.out.println("Enter your cellphone number: " + " (must contain a international country code(+27)");
            cellPhoneNumber = input.nextLine();
            System.out.println(registration.returncheckCellPhoneNumberMessage(cellPhoneNumber));
        }while (!registration.checkCellPhoneNumber(cellPhoneNumber));

        System.out.println("---> Login <---");
        //Login object with registration credentials
        Login login = new Login(username, password);

        //this code is for variable to track login status
        boolean loggedIn = false;

        //loop will continue until user enters the right credentials
        while (!loggedIn) {
            System.out.println("Enter your username: ");
            String loginUserName = input.nextLine();

            System.out.println("Enter your password: ");
            String loginPassword = input.nextLine();

            //check if entered credentials match the stored credentials
            if (login.loginUser(loginUserName, loginPassword)) {
                System.out.println("Welcome " + firstName + " " + lastName + ", " +"it is great to see you again.");
                loggedIn = true;
            } else {
                System.out.println("Username or password incorrect, please try again.");
            }

        }
    }
    /*User registration */

    public class Registration {
        //username validation
        public boolean checkUserName(String username){

            if(username.contains("_") && username.length()<=5) {
                return true;
            } else {
                return false;

            }
        }
        //Method returning the correct message
        public String returnUserNameMessage(String username){
            if (checkUserName(username)) {
                return "Username successfully captured.";
            } else {
                return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";

            }
        }
        //the method to validate the password
        public boolean checkPasswordComplexity(String password){

            if (password.length()>=8 &&
                    password.matches(".*[A-Z].*") &&
                    password.matches(".*[0-9].*") &&
                    password.matches(".*[^a-zA-Z0-9].*")){
                return true;
            } else {
                return false;
            }
        }
        //Method returning the correct message
        public String returnCheckPasswordMessage(String password){
            if (checkPasswordComplexity(password)){
                return "Password successfully captured.";
            } else {
                return "Password is not correctly formatted,please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
            }
        }
        //cellphone number validation
        public boolean checkCellPhoneNumber(String cellPhoneNumber){
            if (cellPhoneNumber.matches("\\+27\\d{9}")) {
                return true;
            } else {
                return false;
            }

        }
        //Method returning the correct message
        public String returncheckCellPhoneNumberMessage(String cellPhoneNumber) {
            if (checkCellPhoneNumber(cellPhoneNumber)){
                return "Cell phone number successfully added.";
            } else {
                return "Cell phone number incorrectly formatted or does not contain international code(+27); please correct the number and try again.";
            }
        }
    }

    /* Below code is for Public class User information */

    public class User {
        //Instance variables used to store user information
        private String username;
        private String password;
        private String cellPhoneNumber;

        //constructor to fill those variables for a new user
        public User(String username, String password, String cellPhoneNumber){
            this.username = username;
            this.password = password;
            this.cellPhoneNumber = cellPhoneNumber;
        }
    }


/* below public class is for user data storing */

    
    public class Login {
        /*Instance variables used to store user credentials */
        private String storedUserName;
        private String storedPassword;

        //constructor to fill those variables
        public Login(String storedUserName, String storedPassword) {
            this.storedUserName = storedUserName;
            this.storedPassword = storedPassword;
        }
        //Method to verify credentials
        public boolean loginUser(String enteredUserName, String enteredPassword){
            if (storedUserName.equals(enteredUserName) && storedPassword.equals(enteredPassword)) {
                return true;
            } else {
                return false;
            }

        }
        //Method to return the correct message
        public String returnLoginStatus(String enteredUserName, String enteredPassword,
                                        String firstName, String lastName) {
            if(loginUser(enteredUserName, enteredPassword)) {
                return "Welcome " + firstName + " " + lastName + ", " +"it is great to see you again.";
            } else
                return "Username or password incorrect, please try again.";
        }
    }

}